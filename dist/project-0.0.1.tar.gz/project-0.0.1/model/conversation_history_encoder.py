import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
import pickle
import numpy as np
import os
from model.UV_Encoders import UV_Encoder
from model.UV_Aggregators import UV_Aggregator
from model.attention import SelfAttentionBatch, SelfAttentionSeq
from model.transformer import TransformerDecoder, TransformerEncoder

class ConversationHistoryEncoder(nn.Module):
    def __init__(self, embedding_weights, token_emb_dim, user_emb_dim, n_heads, 
                 n_layers, ffn_size, vocab_size, dropout, attention_dropout, relu_dropout, pad_token_idx,
                 start_token_idx, learn_positional_embeddings, embeddings_scale, reduction, n_positions, device):
        super(ConversationHistoryEncoder, self).__init__()
        self.embedding_weights = embedding_weights
        self.token_emb_dim = token_emb_dim
        self.user_emb_dim = user_emb_dim
        self.n_heads = n_heads
        self.n_layers = n_layers
        self.ffn_size = ffn_size
        self.vocab_size = vocab_size
        self.dropout = dropout
        self.attention_dropout = attention_dropout
        self.relu_dropout = relu_dropout
        self.pad_token_idx = pad_token_idx
        self.start_token_idx = start_token_idx
        self.learn_positional_embeddings = learn_positional_embeddings
        self.embeddings_scale = embeddings_scale
        self.reduction = reduction
        self.n_positions = n_positions
        self.device = device
        self= self.to(self.device)

        self._build_model()

    def _build_model(self):
        self.initEmbeddings()
        self._build_context_transformer_layer()
        self._build_context_cl_project_head()
        self._build_atten()
    
    
    def initEmbeddings(self):
        if self.embedding_weights is not None:
                pretrained_embeddings = torch.load(self.embedding_weights)
                self.embedding = nn.Embedding.from_pretrained(pretrained_embeddings, freeze=False,padding_idx=self.pad_token_idx)
        else :
            self.embedding = nn.Embedding(self.vocab_size, self.token_emb_dim, self.pad_token_idx)
            nn.init.normal_(self.embedding.weight, mean=0, std=self.user_emb_dim ** -0.5)
            nn.init.constant_(self.embedding.weight[self.pad_token_idx], 0)     
    def _build_context_transformer_layer(self):
        self.register_buffer('C_START', torch.tensor([self.start_token_idx], dtype=torch.long))

        self.context_encoder = TransformerEncoder(
            self.n_heads,
            self.n_layers,
            self.token_emb_dim,
            self.ffn_size,
            self.vocab_size,
            self.embedding,
            self.dropout,
            self.attention_dropout,
            self.relu_dropout,
            self.pad_token_idx,
            self.learn_positional_embeddings,
            self.embeddings_scale,
            self.reduction,
            self.n_positions
        )


    def _build_context_cl_project_head(self):
        self.context_project_head_fc1 = nn.Linear(self.token_emb_dim, self.token_emb_dim)
        self.context_project_head_fc2 = nn.Linear(self.token_emb_dim, self.user_emb_dim)

    def _build_atten(self):
        self.ContextHiddenStateAttenFunc = SelfAttentionSeq(self.token_emb_dim, self.token_emb_dim)

    

    def get_project_context_rep(self, batch):
        context = batch['context'].to(self.device)  # (bs, seq_len) it might be context_tokens
        context_mask = batch['context_mask'].to(self.device)  # (bs, seq_len)
        context_pad_mask = batch['context_pad_mask'].to(self.device)  # (bs, seq_len)    this is maybe the entites_mask_in_context

        context_user_rep = self._get_context_user_rep(context, context_mask, context_pad_mask) # (bs, dim), (bs, seq_len, dim)
        project_context_user_rep = self._project_context_user_rep(context_user_rep)  # (bs, user_dim)


        return project_context_user_rep # (bs, user_dim)
    
       
    def _get_context_user_rep(self, context, context_mask, context_pad_mask):
        cls_state, state = self._get_hidden_state_context_transformer(context)  # (bs, dim), (bs, seq_len, dim)
        atten_last_state = self.ContextHiddenStateAttenFunc(state, context_pad_mask)  # (bs, dim)

        assert len(atten_last_state.shape) == 2
        return atten_last_state  # (bs, dim)

    def _get_hidden_state_context_transformer(self, context):
        state, mask = self.context_encoder(context)
        cls_state = state[:, 0, :] # (bs, dim)

        return cls_state, state

    def _project_context_user_rep(self, context_user_rep):
        # context_user_rep = (bs, dim)
        context_user_rep = self.context_project_head_fc1(context_user_rep) # (bs, dim)
        context_user_rep = F.relu(context_user_rep) # (bs, dim)
        context_user_rep = self.context_project_head_fc2(context_user_rep) # (bs, user_dim)

        return context_user_rep # (bs, user_dim)