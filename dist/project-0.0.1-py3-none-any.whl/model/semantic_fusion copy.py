'''
Author: “glad47” ggffhh3344@gmail.com
Date: 2024-05-05 09:29:08
LastEditors: “glad47” ggffhh3344@gmail.com
LastEditTime: 2024-05-14 15:53:08
Description: user-item graph 
'''
import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
import pickle
from model.entitiy_relationships_graph import EntityRelationshipGraph
from model.user_interactions_graph import UserItemGraph
from model.user_social_graph import UserSocialGraph
from model.conversation_history_encoder import ConversationHistoryEncoder
from model.info_nce_loss import info_nce_loss
class SemanticFusion(nn.Module):

    def __init__(self, dir_data, social_embed_dim, interaction_embed_dim, user_embed_dim, 
                 weights_loc_social, weights_loc_interaction, kg_emb_dim, n_entity, num_bases, graph_dataset,
                 token_embedding_weights, token_emb_dim, n_heads, n_layers, ffn_size, vocab_size, dropout, attention_dropout, 
                 relu_dropout, pad_token_idx, start_token_idx, learn_positional_embeddings, embeddings_scale, reduction, n_positions,
                 temperature, device):
        super(SemanticFusion, self).__init__()

        self.dir_data = dir_data
        self.social_embed_dim = social_embed_dim
        self.interaction_embed_dim = interaction_embed_dim
        self.weights_loc_social= weights_loc_social
        self.weights_loc_interaction= weights_loc_interaction
        self.user_embed_dim = user_embed_dim
        self.kg_emb_dim = kg_emb_dim 
        self.n_entity = n_entity
        self.graph_dataset = graph_dataset
        self.num_bases = num_bases
        self.token_embedding_weights = token_embedding_weights
        self.token_emb_dim = token_emb_dim
        self.n_heads = n_heads
        self.n_layers = n_layers
        self.ffn_size = ffn_size
        self.vocab_size = vocab_size
        self.dropout = dropout
        self.attention_dropout = attention_dropout
        self.relu_dropout = relu_dropout
        self.pad_token_idx = pad_token_idx
        self.start_token_idx = start_token_idx
        self.learn_positional_embeddings = learn_positional_embeddings
        self.embeddings_scale = embeddings_scale
        self.reduction = reduction
        self.n_positions = n_positions
        self.temperature = temperature
        self.device = device
        self._build_model()
    
    def _build_model(self):
        self.social_graph = UserSocialGraph(self.dir_data, self.social_embed_dim, self.user_embed_dim, self.weights_loc_social, self.device)
        self.interaction_graph = UserItemGraph(self.dir_data, self.interaction_embed_dim, self.user_embed_dim, self.weights_loc_interaction, self.device)
        self.entity_graph = EntityRelationshipGraph(self.kg_emb_dim, self.user_embed_dim, self.n_entity,self.num_bases, self.graph_dataset, self.device )
        self.conversation_encoder = ConversationHistoryEncoder(self.token_embedding_weights, self.token_emb_dim, self.user_embed_dim, self.n_heads,
                                                               self.n_layers, self.ffn_size, self.vocab_size, self.dropout, self.attention_dropout,
                                                               self.relu_dropout, self.pad_token_idx, self.start_token_idx, self.learn_positional_embeddings,
                                                               self.embeddings_scale, self.reduction, self.n_positions, self.device)
        
        self.cross_entory_loss = nn.CrossEntropyLoss(reduction='none')

    def calculate_info_nce_loss(self, user_rep1, user_rep2):
            # user_rep1 = (bs, dim), user_rep2 = (times * bs, dim)
            features= []
            index_pair = {}
            count = 0
            for index,user in enumerate(user_rep1):
                if len(user_rep2[index]) > 1 :
                    for user2 in user_rep2[index]:
                        features.append(torch.cat([user, user2], dim=0))
                        if index_pair.get(index) is None:
                            index_pair[index] = []
                        index_pair[index].append(count)
                        count += 1   
            #features = torch.cat([user_rep1, user_rep2], dim=0) # (2*bs, dim)
            
            features = torch.stack(features, dim=0)
            
            batch_size = features.shape[0]

            logits, labels = info_nce_loss(
                features, 
                bs=batch_size, 
                n_views=1, 
                device=self.device, 
                temperature=self.temperature)
            
            loss = self.cross_entory_loss(logits, labels)
            mean_loss = torch.zeros(user_rep1.shape[0], device=self.device, dtype=torch.float)
            for index, user2_indices in index_pair.items():
                lossValue = 0
                for user2_index in user2_indices:
                    lossValue += loss[user2_index]
                mean_loss[index] = lossValue / len(user2_indices)
            assert mean_loss.shape[0] ==  user_rep1.shape[0]      

            return mean_loss.mean()

    def forward(self, batch):
        social_embeddings = self.social_graph.get_user_social_user_rep(batch)
        interaction_embeddings, _ , _ = self.interaction_graph.get_user_interaction_item_rep(batch)
        entity_embeddings, _ , _= self.entity_graph.get_kg_user_rep(batch)  
        conv_history_embeddings = self.conversation_encoder.get_project_context_rep(batch)
        social_cov_history_loss =self.calculate_info_nce_loss(conv_history_embeddings,social_embeddings)
        interaction_cov_history_loss =self.calculate_info_nce_loss(conv_history_embeddings,interaction_embeddings)
        entity_cov_history_loss =self.calculate_info_nce_loss(conv_history_embeddings,entity_embeddings)
        loss = (social_cov_history_loss + interaction_cov_history_loss + entity_cov_history_loss) / 3.0
   
        return loss
    
    
    